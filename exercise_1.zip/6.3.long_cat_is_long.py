def long_cat_is_long(cat):
    return cat * 2

if __name__ == '__main__':
    print(long_cat_is_long("meow"))
