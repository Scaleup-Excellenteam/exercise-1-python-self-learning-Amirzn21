def remember_remember(thing):
    return f"Remember, remember: {thing}"

if __name__ == '__main__':
    print(remember_remember("the fifth of November"))
