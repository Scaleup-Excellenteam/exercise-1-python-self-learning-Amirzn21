def running_2000(speed, time):
    return speed * time

if __name__ == '__main__':
    print(running_2000(10, 200))
