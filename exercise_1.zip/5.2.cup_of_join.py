def cup_of_join(lst, sep=', '):
    return sep.join(lst)

if __name__ == '__main__':
    print(cup_of_join(['apple', 'banana', 'cherry']))
