def sent_turtle(steps):
    return f"The turtle moved {steps} steps."

if __name__ == '__main__':
    print(sent_turtle(10))
