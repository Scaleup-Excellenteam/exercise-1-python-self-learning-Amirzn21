def communicating_vessels(a, b):
    return a + b

if __name__ == '__main__':
    print(communicating_vessels(5, 10))
